# Kumbara
I created a money saving app using Kotlin <br> <br>
![1](https://user-images.githubusercontent.com/70278989/227964142-b98c5953-a7c2-463f-beff-5be3aea7d4ad.jpg) <br> <br>
![2](https://user-images.githubusercontent.com/70278989/227964161-8698c3a9-19b2-4dbf-964c-26f8d8390900.jpg) <br> <br>
![3](https://user-images.githubusercontent.com/70278989/227964187-45b856d1-0cbf-4002-9cbb-73edce6d25c9.jpg) <br> <br>
![4](https://user-images.githubusercontent.com/70278989/227964204-4ea21177-795a-463a-87e8-8294db1e87da.jpg) <br> <br>
