package com.uygulamalarim.kumbara.Model

data class Currency(val currencyName: String, val currencyIcon: String)
