package com.uygulamalarim.kumbara.Model

data class CurrencyList(val data: List<Currency>)